import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import db from "./src/lib/db";

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || "fallback_secret_for_dev";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // Middleware to verify JWT
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.sendStatus(403);
      req.user = user;
      next();
    });
  };

  // Auth Routes
  app.post("/api/auth/signup", async (req, res) => {
    const { email, password, displayName } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const id = uuidv4();

    try {
      const stmt = db.prepare("INSERT INTO users (id, email, password, displayName) VALUES (?, ?, ?, ?)");
      stmt.run(id, email, hashedPassword, displayName);
      
      const token = jwt.sign({ id, email }, JWT_SECRET);
      res.json({ token, user: { id, email, displayName } });
    } catch (error: any) {
      res.status(400).json({ error: "User already exists or invalid data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);
    res.json({ token, user: { id: user.id, email: user.email, displayName: user.displayName } });
  });

  // Transaction Routes
  app.get("/api/transactions", authenticateToken, (req: any, res) => {
    const transactions = db.prepare("SELECT * FROM transactions WHERE userId = ? ORDER BY date DESC").all(req.user.id);
    res.json(transactions);
  });

  app.get("/api/transactions/:id", authenticateToken, (req: any, res) => {
    const transaction = db.prepare("SELECT * FROM transactions WHERE id = ? AND userId = ?").get(req.params.id, req.user.id);
    if (!transaction) return res.sendStatus(404);
    res.json(transaction);
  });

  app.post("/api/transactions", authenticateToken, (req: any, res) => {
    const { amount, category, date, notes, type, source, paymentMethod } = req.body;
    const id = uuidv4();
    
    const stmt = db.prepare(`
      INSERT INTO transactions (id, userId, amount, category, date, notes, type, source, paymentMethod)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run(id, req.user.id, amount, category, date, notes, type, source, paymentMethod);
    res.json({ id, amount, category, date, notes, type, source, paymentMethod });
  });

  app.delete("/api/transactions/:id", authenticateToken, (req: any, res) => {
    const stmt = db.prepare("DELETE FROM transactions WHERE id = ? AND userId = ?");
    const result = stmt.run(req.params.id, req.user.id);
    
    if (result.changes === 0) return res.sendStatus(404);
    res.sendStatus(204);
  });

  app.put("/api/transactions/:id", authenticateToken, (req: any, res) => {
    const { amount, category, date, notes, type, source, paymentMethod } = req.body;
    
    const stmt = db.prepare(`
      UPDATE transactions 
      SET amount = ?, category = ?, date = ?, notes = ?, type = ?, source = ?, paymentMethod = ?
      WHERE id = ? AND userId = ?
    `);
    
    const result = stmt.run(amount, category, date, notes, type, source, paymentMethod, req.params.id, req.user.id);
    
    if (result.changes === 0) return res.sendStatus(404);
    res.json({ id: req.params.id, amount, category, date, notes, type, source, paymentMethod });
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
