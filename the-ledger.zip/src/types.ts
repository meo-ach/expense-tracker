export type Category = 'Food' | 'Travel' | 'Shopping' | 'Utilities' | 'Entertainment' | 'Housing' | 'Leisure' | 'Salary' | 'Investment' | 'Freelance' | 'Rental' | 'Other';

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  category: Category;
  date: string;
  notes?: string;
  type: 'expense' | 'income';
  source?: string; // For income
  paymentMethod?: string; // For expenses
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  createdAt: string;
}
