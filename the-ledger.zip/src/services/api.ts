import { Transaction, UserProfile } from '../types';

const API_URL = '/api';

const getAuthHeader = () => {
  const token = localStorage.getItem('ledger_token');
  return token ? { 'Authorization': `Bearer ${token}` } : {};
};

export const api = {
  auth: {
    login: async (email: string, password: string) => {
      const res = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) throw new Error('Invalid credentials');
      const data = await res.json();
      localStorage.setItem('ledger_token', data.token);
      localStorage.setItem('ledger_user', JSON.stringify(data.user));
      return data;
    },
    signup: async (email: string, password: string, displayName: string) => {
      const res = await fetch(`${API_URL}/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, displayName }),
      });
      if (!res.ok) throw new Error('Signup failed');
      const data = await res.json();
      localStorage.setItem('ledger_token', data.token);
      localStorage.setItem('ledger_user', JSON.stringify(data.user));
      return data;
    },
    logout: () => {
      localStorage.removeItem('ledger_token');
      localStorage.removeItem('ledger_user');
    },
    getUser: (): UserProfile | null => {
      const user = localStorage.getItem('ledger_user');
      return user ? JSON.parse(user) : null;
    }
  },
  transactions: {
    getAll: async (): Promise<Transaction[]> => {
      const res = await fetch(`${API_URL}/transactions`, {
        headers: getAuthHeader(),
      });
      if (!res.ok) throw new Error('Failed to fetch transactions');
      return res.json();
    },
    getById: async (id: string): Promise<Transaction> => {
      const res = await fetch(`${API_URL}/transactions/${id}`, {
        headers: getAuthHeader(),
      });
      if (!res.ok) throw new Error('Failed to fetch transaction');
      return res.json();
    },
    create: async (transaction: Omit<Transaction, 'id' | 'userId' | 'createdAt'>): Promise<Transaction> => {
      const res = await fetch(`${API_URL}/transactions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader(),
        },
        body: JSON.stringify(transaction),
      });
      if (!res.ok) throw new Error('Failed to create transaction');
      return res.json();
    },
    update: async (id: string, transaction: Omit<Transaction, 'id' | 'userId' | 'createdAt'>): Promise<Transaction> => {
      const res = await fetch(`${API_URL}/transactions/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader(),
        },
        body: JSON.stringify(transaction),
      });
      if (!res.ok) throw new Error('Failed to update transaction');
      return res.json();
    },
    delete: async (id: string): Promise<void> => {
      const res = await fetch(`${API_URL}/transactions/${id}`, {
        method: 'DELETE',
        headers: getAuthHeader(),
      });
      if (!res.ok) throw new Error('Failed to delete transaction');
    }
  }
};
