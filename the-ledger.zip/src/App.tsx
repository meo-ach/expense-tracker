/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Signup from './pages/Signup';
import AddExpense from './pages/AddExpense';
import Transactions from './pages/Transactions';
import Income from './pages/Income';
import { api } from './services/api';

export default function App() {
  const [user, setUser] = useState(api.auth.getUser());

  const handleLogin = (userData: any) => {
    setUser(userData.user);
  };

  const handleLogout = () => {
    api.auth.logout();
    setUser(null);
  };

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login onLogin={handleLogin} />} />
        <Route path="/signup" element={<Signup onSignup={handleLogin} />} />
        
        <Route 
          path="/*" 
          element={
            user ? (
              <Layout user={user} onLogout={handleLogout}>
                <Routes>
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/transactions" element={<Transactions />} />
                  <Route path="/income" element={<Income />} />
                  <Route path="/add-expense" element={<AddExpense />} />
                  <Route path="/edit-transaction/:id" element={<AddExpense />} />
                  <Route path="*" element={<Navigate to="/dashboard" replace />} />
                </Routes>
              </Layout>
            ) : (
              <Navigate to="/login" replace />
            )
          } 
        />
      </Routes>
    </Router>
  );
}

