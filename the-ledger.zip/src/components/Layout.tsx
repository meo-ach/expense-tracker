import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, History, DollarSign, User, LogOut } from '../constants';
import { cn } from '../lib/utils';
import { UserProfile } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  user: UserProfile;
  onLogout: () => void;
}

export default function Layout({ children, user, onLogout }: LayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Transactions', path: '/transactions', icon: History },
    { name: 'Income', path: '/income', icon: DollarSign },
  ];

  return (
    <div className="min-h-screen bg-surface text-on-surface font-body selection:bg-primary-fixed selection:text-on-primary-fixed">
      {/* Top Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/70 backdrop-blur-2xl border-b border-outline-variant/10">
        <div className="max-w-[1440px] mx-auto px-6 md:px-28 h-20 flex items-center justify-between">
          <Link to="/dashboard" className="text-2xl font-bold text-primary font-headline tracking-tight">
            The Ledger
          </Link>

          <div className="hidden md:flex items-center space-x-12">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "font-headline font-bold text-sm tracking-tight transition-all duration-300 pb-1 border-b-2",
                  location.pathname === item.path
                    ? "text-primary border-primary"
                    : "text-slate-500 border-transparent hover:text-primary"
                )}
              >
                {item.name}
              </Link>
            ))}
          </div>

          <div className="flex items-center space-x-6">
            <button 
              onClick={() => navigate('/add-expense')}
              className="bg-gradient-to-br from-primary to-primary-container text-on-primary px-6 py-2.5 rounded-xl font-headline font-bold text-sm tracking-tight hover:opacity-90 active:scale-95 transition-all shadow-sm"
            >
              Add Expense
            </button>
            <div className="flex items-center space-x-3">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-on-surface">{user.displayName || user.email}</p>
                <p className="text-[10px] text-on-surface-variant uppercase tracking-widest">Premium Member</p>
              </div>
              <button 
                onClick={onLogout}
                className="text-on-surface-variant hover:bg-secondary/10 hover:text-secondary p-2 rounded-full transition-all"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-20 px-6 md:px-28 max-w-[1440px] mx-auto">
        {children}
      </main>

      <footer className="bg-surface-container-low py-12 border-t border-outline-variant/20">
        <div className="max-w-[1440px] mx-auto px-6 md:px-28 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-[0.6875rem] uppercase tracking-wider text-slate-400 font-label">
            © 2024 THE ETHEREAL LEDGER. EDITORIAL FINANCE.
          </p>
          <div className="flex space-x-8">
            {['Privacy Policy', 'Terms of Service', 'Help Center', 'Feedback'].map((link) => (
              <a key={link} href="#" className="text-[0.6875rem] uppercase tracking-wider text-slate-400 hover:text-primary transition-colors font-label">
                {link}
              </a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
