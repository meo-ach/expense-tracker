import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, DollarSign, Utensils, Plane, ShoppingBag, Zap, Film, Home, Coffee, Briefcase, TrendingUp, Brush, Home as HomeIcon } from '../constants';
import { Category } from '../types';
import { cn } from '../lib/utils';
import { api } from '../services/api';

const CATEGORIES: { label: Category; icon: any }[] = [
  { label: 'Food', icon: Utensils },
  { label: 'Travel', icon: Plane },
  { label: 'Shopping', icon: ShoppingBag },
  { label: 'Utilities', icon: Zap },
  { label: 'Entertainment', icon: Film },
  { label: 'Housing', icon: Home },
  { label: 'Leisure', icon: Coffee },
  { label: 'Salary', icon: Briefcase },
  { label: 'Investment', icon: TrendingUp },
  { label: 'Freelance', icon: Brush },
  { label: 'Rental', icon: HomeIcon },
  { label: 'Other', icon: DollarSign },
];

export default function AddExpense() {
  const { id } = useParams();
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<Category>('Food');
  const [notes, setNotes] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [type, setType] = useState<'expense' | 'income'>('expense');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      const fetchTransaction = async () => {
        try {
          const t = await api.transactions.getById(id);
          setAmount(t.amount.toString());
          setCategory(t.category);
          setNotes(t.notes || '');
          setDate(t.date);
          setType(t.type);
        } catch (err) {
          console.error('Failed to fetch transaction', err);
          navigate('/dashboard');
        }
      };
      fetchTransaction();
    }
  }, [id, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const transactionData = {
        amount: parseFloat(amount),
        category,
        date,
        notes,
        type,
        source: type === 'income' ? (notes || 'Income') : undefined,
        paymentMethod: type === 'expense' ? 'Standard' : undefined
      };

      if (id) {
        await api.transactions.update(id, transactionData);
      } else {
        await api.transactions.create(transactionData);
      }
      navigate('/dashboard');
    } catch (err) {
      console.error('Failed to save transaction', err);
      alert('Failed to save transaction');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-12">
      <div className="flex items-center justify-between">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center space-x-2 text-on-surface-variant hover:text-primary transition-colors group"
        >
          <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          <span className="text-[0.6875rem] font-label font-bold uppercase tracking-widest">Back to Dashboard</span>
        </button>
        <h1 className="text-3xl font-headline font-extrabold tracking-tight">
          {id ? 'Edit Transaction' : 'New Transaction'}
        </h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-10 bg-surface-container-lowest p-12 rounded-3xl shadow-[0_20px_60px_rgba(25,28,30,0.04)]">
        {/* Type Toggle */}
        <div className="flex bg-surface-container p-1.5 rounded-2xl">
          <button
            type="button"
            onClick={() => setType('expense')}
            className={cn(
              "flex-1 py-3 rounded-xl font-headline font-bold text-sm transition-all",
              type === 'expense' ? "bg-white text-secondary shadow-sm" : "text-on-surface-variant hover:text-on-surface"
            )}
          >
            Expense
          </button>
          <button
            type="button"
            onClick={() => setType('income')}
            className={cn(
              "flex-1 py-3 rounded-xl font-headline font-bold text-sm transition-all",
              type === 'income' ? "bg-white text-primary shadow-sm" : "text-on-surface-variant hover:text-on-surface"
            )}
          >
            Income
          </button>
        </div>

        {/* Amount Input */}
        <div className="space-y-4 text-center">
          <label className="text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400">Transaction Amount</label>
          <div className="relative inline-block">
            <span className="absolute left-0 top-1/2 -translate-y-1/2 text-4xl font-headline font-bold text-slate-300">$</span>
            <input 
              type="number"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-transparent border-none text-center text-[4rem] font-headline font-extrabold tracking-tight focus:ring-0 w-full max-w-[300px] placeholder:text-slate-100"
              placeholder="0.00"
              required
            />
          </div>
        </div>

        {/* Category Grid */}
        <div className="space-y-4">
          <label className="text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400 ml-1">Select Category</label>
          <div className="grid grid-cols-3 md:grid-cols-4 gap-4">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.label}
                type="button"
                onClick={() => setCategory(cat.label)}
                className={cn(
                  "flex flex-col items-center justify-center p-4 rounded-2xl border-2 transition-all space-y-2",
                  category === cat.label 
                    ? "border-primary bg-primary/5 text-primary" 
                    : "border-transparent bg-surface-container-low text-on-surface-variant hover:bg-surface-container-high"
                )}
              >
                <cat.icon className="w-6 h-6" />
                <span className="text-[0.625rem] font-label font-bold uppercase tracking-wider">{cat.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400 ml-1">Date</label>
            <input 
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-surface-container-low border-none rounded-2xl py-4 px-6 focus:ring-2 focus:ring-primary/20 transition-all font-body"
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400 ml-1">Notes (Optional)</label>
            <input 
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-surface-container-low border-none rounded-2xl py-4 px-6 focus:ring-2 focus:ring-primary/20 transition-all font-body"
              placeholder="What was this for?"
            />
          </div>
        </div>

        <button 
          type="submit"
          disabled={loading}
          className={cn(
            "w-full py-5 rounded-2xl font-headline font-bold text-lg tracking-tight hover:opacity-90 active:scale-[0.98] transition-all shadow-lg disabled:opacity-50",
            type === 'expense' ? "bg-secondary text-on-secondary shadow-secondary/20" : "bg-primary text-on-primary shadow-primary/20"
          )}
        >
          {loading ? 'Saving...' : (id ? 'Update Transaction' : 'Confirm Transaction')}
        </button>
      </form>
    </div>
  );
}
