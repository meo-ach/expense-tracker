import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  TrendingUp, ArrowDown, ArrowUp, History, Utensils, 
  Briefcase, Plane, ShoppingBag, Plus, Wallet, 
  ArrowUpRight, ArrowDownRight, MoreHorizontal 
} from '../constants';
import { cn } from '../lib/utils';
import { api } from '../services/api';
import { Transaction } from '../types';
import { CATEGORY_ICONS } from '../constants';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, PieChart, Pie, Cell 
} from 'recharts';

export default function Dashboard() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await api.transactions.getAll();
        setTransactions(data);
      } catch (err) {
        console.error('Failed to fetch dashboard data', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((acc, t) => acc + t.amount, 0);

  const totalExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => acc + t.amount, 0);

  const balance = totalIncome - totalExpenses;

  // Chart Data: Spending Pulse (Last 7 days)
  const spendingPulseData = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const dateStr = date.toISOString().split('T')[0];
    const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
    
    const dayExpenses = transactions
      .filter(t => t.type === 'expense' && t.date === dateStr)
      .reduce((acc, t) => acc + t.amount, 0);
      
    return { name: dayName, amount: dayExpenses };
  });

  // Chart Data: Allocation (By Category)
  const allocationData = Object.entries(
    transactions
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount;
        return acc;
      }, {} as Record<string, number>)
  ).map(([name, value]) => ({ name, value }));

  const COLORS = ['#F27D26', '#191C1E', '#4A4A4A', '#8E9299', '#D1D1D1'];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-2">
          <h1 className="text-4xl font-headline font-extrabold tracking-tight">Dashboard</h1>
          <p className="text-on-surface-variant font-body">Welcome back! Here's what's happening with your money.</p>
        </div>
        <button 
          onClick={() => navigate('/add-expense')}
          className="flex items-center justify-center space-x-2 bg-primary text-on-primary px-8 py-4 rounded-2xl font-headline font-bold shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          <Plus className="w-5 h-5" />
          <span>Add Transaction</span>
        </button>
      </div>

      {/* Summary Cards */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-surface-container-lowest p-10 rounded-xl shadow-[0_12px_40px_rgba(25,28,30,0.04)] flex flex-col justify-between min-h-[220px] relative overflow-hidden">
          <span className="text-[0.6875rem] uppercase tracking-wider font-label font-bold text-on-surface-variant">
            Available Balance
          </span>
          <h2 className="font-headline text-[3rem] font-extrabold tracking-tight leading-tight text-on-surface">
            ${balance.toLocaleString()}
          </h2>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-surface-container-high">
              <TrendingUp className="w-5 h-5 text-primary" />
            </div>
            <span className="text-[0.875rem] font-body text-on-surface-variant">
              Current standing
            </span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-primary to-primary-container p-10 rounded-xl shadow-[0_12px_40px_rgba(25,28,30,0.04)] flex flex-col justify-between min-h-[220px] relative overflow-hidden">
          <span className="text-[0.6875rem] uppercase tracking-wider font-label font-bold text-on-primary/80">
            Total Income
          </span>
          <h2 className="font-headline text-[3rem] font-extrabold tracking-tight leading-tight text-on-primary">
            ${totalIncome.toLocaleString()}
          </h2>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-white/20">
              <ArrowDown className="w-5 h-5 text-on-primary" />
            </div>
            <span className="text-[0.875rem] font-body text-on-primary">
              {transactions.filter(t => t.type === 'income').length} streams
            </span>
          </div>
        </div>

        <div className="bg-surface-container-lowest p-10 rounded-xl shadow-[0_12px_40px_rgba(25,28,30,0.04)] flex flex-col justify-between min-h-[220px] relative overflow-hidden">
          <span className="text-[0.6875rem] uppercase tracking-wider font-label font-bold text-on-surface-variant">
            Total Expenses
          </span>
          <h2 className="font-headline text-[3rem] font-extrabold tracking-tight leading-tight text-on-surface">
            ${totalExpenses.toLocaleString()}
          </h2>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-surface-container-high">
              <ArrowUp className="w-5 h-5 text-secondary" />
            </div>
            <span className="text-[0.875rem] font-body text-on-surface-variant">
              {transactions.filter(t => t.type === 'expense').length} transactions
            </span>
          </div>
          <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-secondary/5 rounded-full blur-2xl" />
        </div>
      </section>

      {/* Charts Section */}
      <section className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Spending Pulse */}
        <div className="lg:col-span-3 bg-surface-container-lowest p-8 rounded-xl shadow-[0_12px_40px_rgba(25,28,30,0.04)] space-y-8">
          <div className="flex justify-between items-end">
            <div>
              <h3 className="font-headline text-xl font-bold tracking-tight">Spending Pulse</h3>
              <p className="text-on-surface-variant text-sm font-body">Daily expense activity for the last 7 days</p>
            </div>
            <div className="flex space-x-2">
              <button className="px-4 py-1.5 rounded-full bg-primary/10 text-[0.6875rem] font-bold text-primary">WEEK</button>
              <button className="px-4 py-1.5 rounded-full bg-surface-container text-[0.6875rem] font-bold text-on-surface-variant hover:bg-primary/10 hover:text-primary transition-colors">MONTH</button>
            </div>
          </div>
          
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={spendingPulseData}>
                <defs>
                  <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F27D26" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#F27D26" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E4E3E0" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#8E9299', fontWeight: 600 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#8E9299', fontWeight: 600 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#191C1E', 
                    border: 'none', 
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px'
                  }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="amount" 
                  stroke="#F27D26" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorAmount)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Allocation */}
        <div className="lg:col-span-2 bg-surface-container-lowest p-8 rounded-xl shadow-[0_12px_40px_rgba(25,28,30,0.04)]">
          <h3 className="font-headline text-xl font-bold tracking-tight mb-6">Allocation</h3>
          <div className="flex flex-col items-center space-y-8">
            <div className="relative w-48 h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={allocationData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {allocationData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-[0.625rem] font-bold text-on-surface-variant uppercase tracking-widest">Top</span>
                <span className="text-lg font-headline font-bold">
                  {allocationData.length > 0 ? [...allocationData].sort((a, b) => (b.value as number) - (a.value as number))[0].name : 'None'}
                </span>
              </div>
            </div>
            <div className="w-full space-y-3">
              {allocationData.slice(0, 4).map((item, index) => (
                <div key={item.name} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                    <span className="text-xs font-medium">{item.name}</span>
                  </div>
                  <span className="text-xs font-bold">${item.value.toLocaleString()}</span>
                </div>
              ))}
              {allocationData.length === 0 && (
                <p className="text-xs text-on-surface-variant italic text-center">No expense data</p>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Recent Activity */}
      <section className="bg-surface-container-lowest p-10 rounded-xl shadow-[0_12px_40px_rgba(25,28,30,0.04)]">
        <div className="flex justify-between items-center mb-10">
          <div>
            <h3 className="font-headline text-2xl font-bold tracking-tight text-on-surface">Recent Activity</h3>
            <p className="text-on-surface-variant font-body text-sm mt-1">Reflecting your latest lifestyle choices</p>
          </div>
          <button 
            onClick={() => navigate('/transactions')}
            className="bg-surface-container-high text-on-surface px-8 py-3 rounded-xl font-bold text-sm hover:bg-surface-container-highest transition-colors active:scale-95"
          >
            View All
          </button>
        </div>
        <div className="space-y-6">
          {transactions.slice(0, 5).map((item) => {
            const Icon = CATEGORY_ICONS[item.category] || History;
            const isIncome = item.type === 'income';
            return (
              <div 
                key={item.id} 
                onClick={() => navigate(`/edit-transaction/${item.id}`)}
                className="flex items-center justify-between group cursor-pointer p-2 -m-2 rounded-xl hover:bg-surface-container-low transition-colors"
              >
                <div className="flex items-center space-x-6">
                  <div className={cn(
                    "w-14 h-14 rounded-xl flex items-center justify-center",
                    isIncome ? "bg-primary-fixed text-primary" : "bg-secondary-fixed text-secondary"
                  )}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-headline font-bold text-on-surface tracking-tight">
                      {item.notes || (isIncome ? item.source : item.category)}
                    </p>
                    <p className="text-on-surface-variant text-[0.6875rem] uppercase tracking-wider font-label font-bold">
                      {item.category} • {new Date(item.date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={cn("font-headline font-bold tracking-tight text-lg", isIncome ? "text-primary" : "text-secondary")}>
                    {isIncome ? '+' : '-'}${Math.abs(item.amount).toLocaleString()}
                  </p>
                  <p className="text-[0.6875rem] font-label text-outline uppercase tracking-widest">
                    {item.paymentMethod || 'Standard'}
                  </p>
                </div>
              </div>
            );
          })}
          {transactions.length === 0 && (
            <div className="py-10 text-center">
              <p className="text-on-surface-variant font-body italic">No recent transactions</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
