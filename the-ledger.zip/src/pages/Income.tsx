import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase, TrendingUp, Brush, Home as HomeIcon, DollarSign, Plus, ArrowUpRight } from '../constants';
import { Transaction, Category } from '../types';
import { cn } from '../lib/utils';
import { api } from '../services/api';
import { CATEGORY_ICONS } from '../constants';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, Legend 
} from 'recharts';

export default function Income() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await api.transactions.getAll();
        setTransactions(data.filter(t => t.type === 'income'));
      } catch (err) {
        console.error('Failed to fetch income data', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const totalMonthlyIncome = transactions.reduce((acc, t) => acc + t.amount, 0);
  const projectedAnnual = totalMonthlyIncome * 12;

  interface IncomeSource {
    id: string;
    name: string;
    category: Category;
    amount: number;
    lastReceived: string;
    count: number;
  }

  // Group income by source/notes for the list
  const incomeSources: IncomeSource[] = Object.values(
    transactions.reduce((acc, t) => {
      const key = t.notes || t.category;
      if (!acc[key]) {
        acc[key] = { 
          id: t.id, 
          name: key, 
          category: t.category, 
          amount: 0, 
          lastReceived: t.date,
          count: 0
        };
      }
      acc[key].amount += t.amount;
      acc[key].count += 1;
      if (new Date(t.date) > new Date(acc[key].lastReceived)) {
        acc[key].lastReceived = t.date;
      }
      return acc;
    }, {} as Record<string, IncomeSource>)
  );

  // Chart Data: Monthly Income Growth (Last 6 months)
  const incomeGrowthData = Array.from({ length: 6 }, (_, i) => {
    const date = new Date();
    date.setMonth(date.getMonth() - (5 - i));
    const monthName = date.toLocaleDateString('en-US', { month: 'short' });
    const month = date.getMonth();
    const year = date.getFullYear();
    
    const monthIncome = transactions
      .filter(t => {
        const tDate = new Date(t.date);
        return tDate.getMonth() === month && tDate.getFullYear() === year;
      })
      .reduce((acc, t) => acc + t.amount, 0);
      
    return { name: monthName, actual: monthIncome, projected: totalMonthlyIncome };
  });

  if (loading) return <div className="flex items-center justify-center h-96">Loading...</div>;

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-6 md:space-y-0">
        <div>
          <h1 className="text-4xl font-headline font-extrabold tracking-tight">Income Streams</h1>
          <p className="text-on-surface-variant font-body text-sm mt-2">Managing your wealth generation channels</p>
        </div>
        
        <button 
          onClick={() => navigate('/add-expense')}
          className="bg-primary text-on-primary px-8 py-4 rounded-2xl font-headline font-bold text-sm tracking-tight flex items-center space-x-3 hover:opacity-90 active:scale-95 transition-all shadow-lg shadow-primary/20"
        >
          <Plus className="w-5 h-5" />
          <span>Add Income Source</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Summary Card */}
        <div className="lg:col-span-1 bg-gradient-to-br from-primary to-primary-container p-10 rounded-3xl shadow-[0_20px_60px_rgba(25,28,30,0.08)] text-on-primary flex flex-col justify-between min-h-[300px]">
          <div className="space-y-2">
            <span className="text-[0.6875rem] font-label font-bold uppercase tracking-widest text-on-primary/70">Total Monthly Income</span>
            <h2 className="text-[3.5rem] font-headline font-extrabold tracking-tight leading-tight">${totalMonthlyIncome.toLocaleString()}</h2>
          </div>
          <div className="space-y-6">
            <div className="flex items-center justify-between border-t border-white/20 pt-6">
              <span className="text-sm font-body text-on-primary/80">Active Streams</span>
              <span className="text-lg font-headline font-bold">{incomeSources.length} Sources</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-body text-on-primary/80">Projected Annual</span>
              <span className="text-lg font-headline font-bold">${projectedAnnual.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Income Sources List */}
        <div className="lg:col-span-2 space-y-6">
          {incomeSources.map((source) => {
            const Icon = CATEGORY_ICONS[source.category] || Briefcase;
            return (
              <div 
                key={source.id} 
                onClick={() => navigate(`/edit-transaction/${source.id}`)}
                className="bg-surface-container-lowest p-8 rounded-3xl shadow-[0_12px_40px_rgba(25,28,30,0.04)] flex items-center justify-between group hover:bg-surface-container-low transition-colors cursor-pointer"
              >
                <div className="flex items-center space-x-6">
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center bg-primary-fixed text-primary">
                    <Icon className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="font-headline font-bold text-xl tracking-tight text-on-surface">{source.name}</h3>
                    <div className="flex items-center space-x-3 mt-1">
                      <span className="text-[0.625rem] font-label font-bold uppercase tracking-widest text-on-surface-variant bg-surface-container-high px-3 py-1 rounded-full">
                        {source.category}
                      </span>
                      <span className="text-[0.625rem] font-label font-bold uppercase tracking-widest text-slate-400">
                        {source.count > 1 ? `${source.count} payments` : 'One-time'}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right flex items-center space-x-8">
                  <div>
                    <p className="font-headline font-bold text-primary text-2xl tracking-tight">+${source.amount.toLocaleString()}</p>
                    <p className="text-[0.625rem] font-label text-slate-400 uppercase tracking-widest mt-1">Last: {new Date(source.lastReceived).toLocaleDateString()}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all group-hover:translate-x-0 translate-x-4">
                    <ArrowUpRight className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </div>
            );
          })}
          {incomeSources.length === 0 && (
            <div className="bg-surface-container-lowest p-12 rounded-3xl text-center">
              <p className="text-on-surface-variant font-body italic">No income sources found.</p>
            </div>
          )}
        </div>
      </div>

      {/* Income Analytics */}
      <div className="bg-surface-container-lowest p-12 rounded-3xl shadow-[0_20px_60px_rgba(25,28,30,0.04)] space-y-10">
        <div className="flex justify-between items-end">
          <div>
            <h3 className="font-headline text-2xl font-bold tracking-tight">Income Growth</h3>
            <p className="text-on-surface-variant font-body text-sm mt-1">Tracking your financial expansion over time</p>
          </div>
          <div className="flex space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-primary" />
              <span className="text-xs font-bold text-on-surface-variant uppercase tracking-widest">Actual</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-surface-container-high" />
              <span className="text-xs font-bold text-on-surface-variant uppercase tracking-widest">Projected</span>
            </div>
          </div>
        </div>
        
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={incomeGrowthData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E4E3E0" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fill: '#8E9299', fontWeight: 600 }}
                dy={10}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fill: '#8E9299', fontWeight: 600 }}
              />
              <Tooltip 
                cursor={{ fill: '#F5F5F4' }}
                contentStyle={{ 
                  backgroundColor: '#191C1E', 
                  border: 'none', 
                  borderRadius: '12px',
                  color: '#fff',
                  fontSize: '12px'
                }}
                itemStyle={{ color: '#fff' }}
              />
              <Bar dataKey="actual" fill="#F27D26" radius={[4, 4, 0, 0]} barSize={40} />
              <Bar dataKey="projected" fill="#E4E3E0" radius={[4, 4, 0, 0]} barSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
