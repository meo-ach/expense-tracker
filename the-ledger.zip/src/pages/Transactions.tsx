import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, ChevronLeft, ChevronRight, Edit, Trash2, History, DollarSign } from '../constants';
import { Category, Transaction } from '../types';
import { cn } from '../lib/utils';
import { api } from '../services/api';
import { CATEGORY_ICONS } from '../constants';

export default function Transactions() {
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'expense' | 'income'>('all');

  const fetchTransactions = async () => {
    try {
      const data = await api.transactions.getAll();
      setTransactions(data);
    } catch (err) {
      console.error('Failed to fetch transactions', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this transaction?')) return;
    try {
      await api.transactions.delete(id);
      setTransactions(prev => prev.filter(t => t.id !== id));
    } catch (err) {
      alert('Failed to delete transaction');
    }
  };

  const filteredTransactions = transactions.filter(t => {
    const name = t.notes || (t.type === 'income' ? t.source : t.category) || '';
    const matchesSearch = name.toLowerCase().includes(searchTerm.toLowerCase()) || t.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filter === 'all' || t.type === filter;
    return matchesSearch && matchesFilter;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-6 md:space-y-0">
        <div>
          <h1 className="text-4xl font-headline font-extrabold tracking-tight">Transaction History</h1>
          <p className="text-on-surface-variant font-body text-sm mt-2">A detailed record of your financial movements</p>
        </div>
        
        <div className="flex items-center space-x-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search transactions..."
              className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-primary/20 transition-all font-body"
            />
          </div>
          <div className="flex bg-surface-container p-1 rounded-2xl">
            {(['all', 'expense', 'income'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cn(
                  "px-6 py-2.5 rounded-xl font-headline font-bold text-xs uppercase tracking-widest transition-all",
                  filter === f ? "bg-white text-primary shadow-sm" : "text-on-surface-variant hover:text-on-surface"
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-surface-container-lowest rounded-3xl shadow-[0_20px_60px_rgba(25,28,30,0.04)] overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-outline-variant/20">
              <th className="px-8 py-6 text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400">Transaction</th>
              <th className="px-8 py-6 text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400">Category</th>
              <th className="px-8 py-6 text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400">Date</th>
              <th className="px-8 py-6 text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400">Method</th>
              <th className="px-8 py-6 text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400 text-right">Amount</th>
              <th className="px-8 py-6 text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-outline-variant/10">
            {filteredTransactions.map((t) => {
              const Icon = CATEGORY_ICONS[t.category as Category] || DollarSign;
              return (
                <tr key={t.id} className="group hover:bg-surface-container-low transition-colors">
                  <td className="px-8 py-6">
                    <div className="flex items-center space-x-4">
                      <div className={cn(
                        "w-12 h-12 rounded-xl flex items-center justify-center",
                        t.type === 'income' ? "bg-primary/10 text-primary" : "bg-secondary/10 text-secondary"
                      )}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <span className="font-headline font-bold tracking-tight text-on-surface">
                        {t.notes || (t.type === 'income' ? t.source : t.category)}
                      </span>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="text-[0.6875rem] font-label font-bold uppercase tracking-widest text-on-surface-variant bg-surface-container-high px-3 py-1 rounded-full">
                      {t.category}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-sm font-body text-on-surface-variant">
                    {new Date(t.date).toLocaleDateString()}
                  </td>
                  <td className="px-8 py-6 text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400">
                    {t.paymentMethod || t.source || 'Standard'}
                  </td>
                  <td className="px-8 py-6 text-right">
                    <span className={cn(
                      "font-headline font-bold tracking-tight text-lg",
                      t.type === 'income' ? "text-primary" : "text-secondary"
                    )}>
                      {t.type === 'income' ? '+' : '-'}${Math.abs(t.amount).toFixed(2)}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <div className="flex items-center justify-end space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => navigate(`/edit-transaction/${t.id}`)}
                        className="p-2 text-on-surface-variant hover:text-primary hover:bg-primary/10 rounded-lg transition-all"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDelete(t.id)}
                        className="p-2 text-on-surface-variant hover:text-secondary hover:bg-secondary/10 rounded-lg transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        
        {filteredTransactions.length === 0 && (
          <div className="py-20 text-center space-y-4">
            <p className="text-on-surface-variant font-body italic">No transactions found matching your criteria.</p>
          </div>
        )}

        <div className="px-8 py-6 border-t border-outline-variant/20 flex items-center justify-between">
          <p className="text-[0.6875rem] font-label font-bold uppercase tracking-widest text-slate-400">
            Showing {filteredTransactions.length} of {transactions.length} entries
          </p>
          <div className="flex items-center space-x-4">
            <button className="p-2 text-on-surface-variant hover:bg-surface-container-high rounded-lg disabled:opacity-30" disabled>
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex space-x-1">
              <button className="w-10 h-10 rounded-lg bg-primary text-on-primary font-bold text-sm">1</button>
              <button className="w-10 h-10 rounded-lg hover:bg-surface-container-high font-bold text-sm">2</button>
            </div>
            <button className="p-2 text-on-surface-variant hover:bg-surface-container-high rounded-lg">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
