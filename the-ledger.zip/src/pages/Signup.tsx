import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, Lock, User, CloudUpload } from '../constants';
import { api } from '../services/api';

interface SignupProps {
  onSignup: (userData: any) => void;
}

export default function Signup({ onSignup }: SignupProps) {
  const [email, setEmail] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      return setError('Passwords do not match');
    }
    setError('');
    setLoading(true);
    try {
      const data = await api.auth.signup(email, password, displayName);
      onSignup(data);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Signup failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white p-12 rounded-3xl shadow-[0_20px_60px_rgba(25,28,30,0.08)] space-y-10 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary to-secondary" />
        
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-secondary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <CloudUpload className="w-10 h-10 text-secondary" />
          </div>
          <h1 className="text-4xl font-headline font-extrabold tracking-tight text-on-surface">Join The Ledger</h1>
          <p className="text-on-surface-variant font-body text-sm">Start your premium financial journey today</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="bg-secondary/10 text-secondary p-4 rounded-xl text-xs font-bold text-center">
              {error}
            </div>
          )}
          <div className="space-y-2">
            <label className="text-[0.6875rem] font-label font-bold uppercase tracking-wider text-slate-400 ml-1">Display Name</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="text" 
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-primary/20 transition-all font-body text-on-surface"
                placeholder="Your Name"
                required
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-[0.6875rem] font-label font-bold uppercase tracking-wider text-slate-400 ml-1">Email Address</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-primary/20 transition-all font-body text-on-surface"
                placeholder="name@example.com"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[0.6875rem] font-label font-bold uppercase tracking-wider text-slate-400 ml-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-primary/20 transition-all font-body text-on-surface"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[0.6875rem] font-label font-bold uppercase tracking-wider text-slate-400 ml-1">Confirm Password</label>
            <div className="relative">
              <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="password" 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-primary/20 transition-all font-body text-on-surface"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-secondary text-on-secondary py-5 rounded-2xl font-headline font-bold text-lg tracking-tight hover:opacity-90 active:scale-[0.98] transition-all shadow-lg shadow-secondary/20 disabled:opacity-50"
          >
            {loading ? 'Creating Account...' : 'Create Account'}
          </button>
        </form>

        <div className="text-center space-y-4">
          <p className="text-on-surface-variant font-body text-sm">
            Already have an account? <Link to="/login" className="text-secondary font-bold hover:underline">Sign In</Link>
          </p>
          <div className="flex items-center justify-center space-x-4 pt-4 border-t border-outline-variant/20">
            <span className="text-[0.6875rem] font-label font-bold text-slate-400 uppercase tracking-widest">Secure Authentication</span>
          </div>
        </div>
      </div>
    </div>
  );
}
